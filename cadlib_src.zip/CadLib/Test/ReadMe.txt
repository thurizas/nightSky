A sample program to demonstrate using of CadIO.dll
